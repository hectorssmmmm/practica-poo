package upm;

import java.util.LinkedList;
import java.util.Scanner;

public class CLI {
    private Scanner scanner;

    public CLI(){
        scanner=new Scanner(System.in);
    }


    public String getCommand(LinkedList<String> ListCommand) {
        StringBuffer sb=new StringBuffer();
        sb.append("This is the list of commands:").append("\n");
        for (String comandb: ListCommand)
            sb.append(comandb).append("\n");
        System.out.println(sb.toString());
        return scanner.nextLine();
    }

    public void print(String text){
        System.out.println(text);
    }


}
