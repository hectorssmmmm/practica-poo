package upm;

public class MatchmakeTeam {
    private Team t1;
    private Team t2;
    public MatchmakeTeam(Team t1, Team t2){
        this.t1 = t1;
        this.t2 = t2;
    }

    public Team getT1() {
        return t1;
    }



    public Team getT2() {
        return t2;
    }

}