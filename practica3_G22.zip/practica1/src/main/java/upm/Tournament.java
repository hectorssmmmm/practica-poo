package upm;

import upm.controllers.MatchmakeController;
import upm.controllers.MatchmakeTeamController;
import upm.controllers.PlayerController;
import upm.controllers.TeamController;

public class Tournament {

    private String name;
    private String dateStart;
    private String dateEnd;
    private String league;
    private  String sport;
    private PlayerController players;
    private TeamController teams;
    private boolean ended;
    private Admin admin;
    private String category;
   private  boolean active;
    private MatchmakeTeamController pairsTeams;
    private MatchmakeController pairs;

    public Tournament(String name, String dateStart, String dateEnd, String league, String sport, Admin admin, String category,PlayerController pc, TeamController tc) {
        this.name = name;
        pairsTeams=new MatchmakeTeamController();
        pairs=new MatchmakeController();
        this.dateStart = dateStart;
        this.dateEnd = dateEnd;
        this.league = league;
        this.sport = sport;
        this.players=pc;
        this.teams=tc;
        ended = false;
        active=false;
        this.admin = admin;
        this.category = category;

    }

    public MatchmakeTeamController getPairsTeams() {
        return pairsTeams;
    }
    public MatchmakeController getPairs() {
        return pairs;
    }
    public PlayerController getPlayers() {
        return players;
    }
    public TeamController getTeams() {
        return teams;
    }

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }
    public Admin getAdmin(){
        return admin;
    }

    public void setAdmin(Admin newAdmin){
        admin = newAdmin;
    }

    public boolean isEnded() {
        return ended;
    }


    public Boolean isActive(){return active;}


}