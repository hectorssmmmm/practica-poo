package upm;

import upm.controllers.PlayerController;

public class Team {
   private Admin admin;
    private PlayerController players;
   private  String name;
  private  int gamesWon;
   boolean pairedTeam;
   double pointsMade;
    double assistancePoints;
    int tournamentsWon;
    double moneyWon;

    public Team(String name ,Admin admin){
        this.admin=admin;
        this.pairedTeam=false;

        this.players=new PlayerController();
        this.name=name ;
        double pMade=1;
        double asPoints=1;
        int toWon=1;
        double moWon=1;
        int gaWon=1;
        for(int i = 0; i<players.getPlayerlist().size() ; i++){
            pMade*=players.getPlayerlist().get(i).getPointsMade();
            asPoints*=players.getPlayerlist().get(i).getAssistancePoints();
            toWon*=players.getPlayerlist().get(i).getTournamentsWon();
            moWon*=players.getPlayerlist().get(i).getMoneyWon();
            gaWon*=players.getPlayerlist().get(i).getGamesWon();
        }
        double num=(double)players.getPlayerlist().size();
        this.pointsMade=Math.pow(pMade , 1/num);
        this.assistancePoints=Math.pow(asPoints , 1/num);
        double toWonaux=(double)toWon;
        this.tournamentsWon= (int)Math.pow( toWonaux, 1/num);
        this.moneyWon=Math.pow(moWon , 1/num);
        double gaWonAux=(double)gaWon;
        this.gamesWon=(int)Math.pow(gaWonAux , 1/num);
    }
    public boolean playerInTeam(String playerId){
        boolean in=false;
        for(int i =0; i<players.getPlayerlist().size();i++){
            if(players.getPlayerlist().get(i).getId().equals(playerId)){
                in=true;
            }
        }return in;
    }
    public boolean isPairedTeam() {
        return pairedTeam;
    }

    public void setPairedTeam(boolean pairedTeam) {
        this.pairedTeam = pairedTeam;
    }



    public Admin getAdmin() {
        return admin;
    }

    public void setAdmin(Admin admin) {
        this.admin = admin;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public PlayerController getPlayers() {
        return players;
    }


}
