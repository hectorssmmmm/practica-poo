package upm;

public class Admin {
    private USER user ;
    private  boolean logged;

    public Admin(String email , String password ){
    user= new USER("ADMIN" , email , password);
    logged=false;
}


    public void setLogged(boolean logged) {
        this.logged = logged;
    }
    public USER getUser() {
        return user;
    }



}
