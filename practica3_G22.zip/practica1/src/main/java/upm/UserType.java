package upm;

public enum UserType {
    PLAYER , ADMIN
}
