package upm.comands.AdminCommand;

import upm.controllers.AdminController;
import upm.controllers.TournamentController;
import upm.comands.Command;

public class TournamentMatchmakingCommand extends Command {
   private  TournamentController controller;
    private AdminController adminController;


    public TournamentMatchmakingCommand(TournamentController controller,AdminController adminController) {
        this.controller = controller;
        this.adminController=adminController;
    }

    @Override
    public String apply() {
        return null;
    }

    public String apply(String[] params) {

        String result = super.testparams(params[0], "tournament-matchmaking", params.length, 2);
        if (result != null && result.isEmpty()) {
            String[] params1 = params[1].split(";");
            if (adminController.getAdminLogged() != null){
                if (params1[0].equals("-at") && params1.length==2) {
                    result = controller.tournamentMatchmakingAutoTeams(params1[1]);
                }else
                    if (params1[0].equals("-ap") && params1.length==2) {
                        result = controller.tournamentMatchmakingAutoPlayers(params1[1]);
                    }else{
                        String r2=super.testparams(params1[0], "-mt", params1.length, 4);
                        if (r2 != null && r2.isEmpty()) {
                            result = controller.tournamentMatchmakingManualTeams(params1[1],params1[2],params1[3]);
                        }else{
                            String r3=super.testparams(params1[0], "-mp", params1.length, 4);
                            if (r3 != null && r3.isEmpty()) {
                                result = controller.tournamentMatchmakingManualPlayers(params1[1],params1[2],params1[3]);
                            }else{
                                result="Command not apply";
                            }
                        }
                    }}else {
                result = "Command not apply until you are logued";
            }
        }return result;
    }

    @Override
    public String toStringCommand() {
        return "tournament-matchmaking -at/-ap/-mp/-mt;tournament;teamOne/playerOne;teamOne/playerTwo";
    }
}
