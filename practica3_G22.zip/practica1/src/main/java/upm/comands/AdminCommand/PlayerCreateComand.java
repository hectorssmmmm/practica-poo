package upm.comands.AdminCommand;

import upm.controllers.AdminController;
import upm.controllers.PlayerController;
import upm.comands.Command;

public class PlayerCreateComand extends Command {
    private PlayerController controller;
    private AdminController adminController;

    public PlayerCreateComand(PlayerController controller,AdminController adminController){
        this.controller=controller;
        this.adminController=adminController;

    }

    @Override
    public String apply() {
        return null;
    }

    public String apply(String[] params){
        String result=super.testparams(params[0], "player-create",params.length,2);
        if (result != null && result.isEmpty()) {
            String[] params1 = params[1].split(";");
            if (adminController.getAdminLogged() != null && params1.length == 5)
                result = controller.createPlayer(params1[0], params1[1], params1[2], params1[3], params1[4],adminController.getAdminLogged());
            else
                result = "Command not apply until you are logued or introduce correct amount of parameters";
        }
        return result;
    }




    @Override
    public String toStringCommand() {
        return "player-create name;surname;id;email;psword";
    }

}
