package upm.comands.AdminCommand;

import upm.controllers.AdminController;
import upm.controllers.PlayerController;
import upm.controllers.TeamController;
import upm.controllers.TournamentController;
import upm.comands.Command;

public class PlayerDeleteCommand extends Command {
    private TournamentController tourcontroller;
        private PlayerController controller;
        private AdminController adminController;
        private TeamController teamController;
        public PlayerDeleteCommand(PlayerController controller, AdminController adminController,TournamentController tourcontroller,TeamController teamController){
            this.controller=controller;
            this.adminController=adminController;
            this.tourcontroller=tourcontroller;
            this.teamController=teamController;


        }

        @Override
        public String apply() {
            return null;
        }

        public String apply(String[] params){
            String result=super.testparams(params[0], "player-delete",params.length,2);
            if (result != null && result.isEmpty()) {
                if (adminController.getAdminLogged() != null) {
                    result = controller.deletePlayer(params[1]) + "\n";
                    result+=teamController.deletePlayer(params[1])+"\n";
                    result += tourcontroller.DeletePlayersFromTournament(params[1]) + "\n";
                    result += tourcontroller.DeletePlayerFromMatchmakes(params[1]) + "\n";
                }else{
                    result = "Command not apply until you are logued";
                }
            }
            return result;
        }



        @Override
        public String toStringCommand() {
            return "player-delete playerId";
        }

    }


