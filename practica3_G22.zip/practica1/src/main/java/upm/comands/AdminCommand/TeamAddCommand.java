package upm.comands.AdminCommand;

import upm.controllers.AdminController;
import upm.controllers.PlayerController;
import upm.controllers.TeamController;
import upm.comands.Command;

public class TeamAddCommand extends Command {
    private TeamController controller;
    private PlayerController pcontroller;
    private AdminController adminController;
    public TeamAddCommand(TeamController controller,PlayerController pcontroller,AdminController adminController){
        this.pcontroller=pcontroller;
        this.controller=controller;
        this.adminController=adminController;
    }

    @Override
    public String apply() {
        return null;
    }

    public String apply(String[] params){
        String result=super.testparams(params[0], "team-add",params.length,2);
        if (result != null && result.isEmpty()) {
            String[] params1 = params[1].split(";");
            if (adminController.getAdminLogged() != null && params1.length == 2){
                    result = controller.addPlayerToATeam(params1[0], params1[1]);
            } else {
                result = "Command not apply until you are logued Incorrect amount of parameters";
            }
        }

        return result;
    }



    @Override
    public String toStringCommand() {
        return "team-add playerId;teamName";
    }

}
