package upm.comands.AdminCommand;

import upm.controllers.AdminController;
import upm.controllers.TeamController;
import upm.comands.Command;

public class TeamRemoveCommand extends Command {
    private TeamController controller;
    private AdminController adminController;
    public TeamRemoveCommand(TeamController controller,AdminController adminController){
        this.controller=controller;
        this.adminController=adminController;
    }

    @Override
    public String apply() {
        return null;
    }

    public String apply(String[] params) {
        String result = super.testparams(params[0], "team-remove", params.length, 2);

        if (result != null && result.isEmpty()) {
            String[] params1 = params[1].split(";");
            if (adminController.getAdminLogged() != null && params1.length==2)
                result = controller.deletePlayerOfATeam(params1[0], params1[1]);
            else
                result = "Command not apply until you are logued or parameters are well writen.";
        }

        return result;

    }


    @Override
    public String toStringCommand() {
        return "team-remove playerId;teamName";}

}
