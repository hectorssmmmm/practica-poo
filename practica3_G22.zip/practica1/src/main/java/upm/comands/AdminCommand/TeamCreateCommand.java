package upm.comands.AdminCommand;

import upm.controllers.AdminController;
import upm.controllers.TeamController;
import upm.comands.Command;

public  class TeamCreateCommand extends Command {
    private TeamController controller;
    private AdminController adminController;

    public TeamCreateCommand(TeamController controller, AdminController adminController){
        this.controller=controller;
        this.adminController=adminController;
    }

    @Override
    public String apply() {
        return null;
    }

    public String apply(String[] params){
    String result=super.testparams(params[0], "team-create",params.length,2);
        if (result != null && result.isEmpty()) {
            if (adminController.getAdminLogged() != null)
                result = controller.createTeam(params[1],adminController.getAdminLogged());
            else
                result = "Command not apply until you are logued";
        }
        return result;
    }



    @Override
    public String toStringCommand() {
        return "team-create name";
    }
}
