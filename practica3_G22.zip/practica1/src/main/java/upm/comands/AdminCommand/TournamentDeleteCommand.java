package upm.comands.AdminCommand;

import upm.controllers.AdminController;
import upm.controllers.TournamentController;
import upm.comands.Command;

public class TournamentDeleteCommand extends Command {

    private TournamentController controller;
    private AdminController adminController;

    public TournamentDeleteCommand(TournamentController controller,AdminController adminController){
        this.adminController=adminController;
        this.controller=controller;
    }

    @Override
    public String apply() {
        return null;
    }

    public String apply(String[] params){
        String result=super.testparams(params[0], "tournament-delete",params.length,2);
        if (result != null && result.isEmpty()) {
            if (adminController.getAdminLogged() != null) {
                if (params.length == 2) {
                    result = controller.tournamentEliminate(params[1]);
                }else{
                    result="Incorrect number of parameters";
                }
            }else {
                result = "Command not apply until you are a logued admin";
            }
        }

        return result;
    }

    @Override
    public String toStringCommand() {
        return "tournament-delete name";
    }
}
