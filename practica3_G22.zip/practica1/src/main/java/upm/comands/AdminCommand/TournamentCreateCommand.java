package upm.comands.AdminCommand;

import upm.controllers.AdminController;
import upm.controllers.PlayerController;
import upm.controllers.TeamController;
import upm.controllers.TournamentController;
import upm.comands.Command;

public class TournamentCreateCommand extends Command {

    private PlayerController playerController;
    private TournamentController controller;
    private AdminController adminController;
    public TournamentCreateCommand(TournamentController controller,AdminController adminController,PlayerController playerController){
        this.controller=controller;
        this.adminController=adminController;
        this.playerController=playerController;
    }

    @Override
    public String apply() {
        return null;
    }

    public String apply(String[] params){
        String result=super.testparams(params[0], "tournament-create",params.length,2);
        if (result != null && result.isEmpty()) {
            String[] params1 = params[1].split(";");
            if (adminController.getAdminLogged() != null && params1.length == 6) {
                result = controller.tournamentCreate(params1[0], params1[1], params1[2], params1[3], params1[4], params1[5],new PlayerController(), new TeamController(playerController));
            } else {
                result = "Number of parameters incorrect or command not apply until you are a logued admin";
            }
        }
        return result;
    }

    @Override
    public String toStringCommand() {
        return "tournament-create name;startDate;endDate;league;sport;categorie";}
}
