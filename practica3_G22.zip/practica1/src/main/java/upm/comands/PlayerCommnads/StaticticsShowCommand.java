package upm.comands.PlayerCommnads;

import upm.controllers.PlayerController;
import upm.comands.Command;

public class StaticticsShowCommand extends Command {
    private PlayerController controller;
    public StaticticsShowCommand(PlayerController controller){
        this.controller=controller;
    }

    @Override
    public String apply() {
        return null;
    }

    public String apply(String[] params){
        String result=super.testparams(params[0], "statistics-show",params.length,2);
        if (result != null && result.isEmpty()) {
            if (controller.getPlayerLoged() != null)
                result = controller.showStatistics(controller.getPlayerLoged().getId(), params[1]);
            else
                result = "Command not apply until you are logued as player.";
        }
        return result;
    }



    @Override
    public String toStringCommand() {
        return "statistics-show -csv/-json";
    }

}
