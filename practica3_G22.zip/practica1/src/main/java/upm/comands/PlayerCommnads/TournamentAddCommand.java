package upm.comands.PlayerCommnads;

import upm.controllers.PlayerController;
import upm.controllers.TournamentController;
import upm.comands.Command;

public class TournamentAddCommand extends Command {
    private TournamentController controller;
    private PlayerController pcontroller;
    public TournamentAddCommand (TournamentController controller,PlayerController pcontroller){
        this.controller=controller;
        this.pcontroller=pcontroller;
    }

    @Override
    public String apply() {
        return null;
    }

    public String apply(String[] params){
        String result="";
        result = super.testparams(params[0], "tournament-add", params.length,2 );
        if(result!=null && result.isEmpty()){

            String[] params1= params[1].split(";");
        if(params1[0].equals("-player")) {
                if (pcontroller.getPlayerLoged()!= null )
                    if(params1.length==2)
                        result = controller.inscribePlayer(params1[1]);
                    else
                    result="Number of parameters incorrect";
                else
                        result = "Command not apply until you are logued as player";
        }else{
            if(params1[0].equals("-team")){
                    if (pcontroller.getPlayerLoged() != null && params1.length==3)
                            result = controller.inscribeTeam(params1[1],params1[2]);
                    else
                            result = "Command not apply until you are logued or introduce correct amount of parameters";

        }}

    }
        return result;
    }



    @Override
    public String toStringCommand() {
        return "tournament-add -player/-team;tournamentName;teamName" ;
    }

}
