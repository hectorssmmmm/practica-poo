package upm.comands;

public abstract class Command {
        public String testparams(String commandin, String commandproposed,
                                 int paramsNumberin, int paramsNumberpropose){
            String result=null;

            if (commandin.toLowerCase().equals(commandproposed))
                if (paramsNumberin==paramsNumberpropose)
                {
                    result = "";
                }
                else
                    result= "Number of params incorrect: expected "+paramsNumberpropose
                            +" found "+paramsNumberin;

            return result;

        }



    public abstract String apply();

    public abstract String apply(String[] params);

    public abstract String toStringCommand();
    }



