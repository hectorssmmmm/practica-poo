package upm.comands.PublicCommand;

import upm.controllers.AdminController;
import upm.controllers.PlayerController;
import upm.comands.Command;

public class LoginCommand extends Command {

    private PlayerController pcontroller;
    private AdminController adcontroller;

    public LoginCommand(PlayerController pcontroller, AdminController adcontroller) {
        this.pcontroller = pcontroller;
        this.adcontroller = adcontroller;
    }

    @Override
    public String apply() {
        return null;
    }

    @Override
    public String apply(String[] params) {
        String result=super.testparams(params[0],"login", params.length,2);

        if(result!=null){
        if (result.isEmpty() ){
            String[] params1= params[1].split(";");
            if(pcontroller.getPlayerLoged()==null && adcontroller.getAdminLogged()==null && params1.length==2)  {
            result = pcontroller.Login(params1[0], params1[1]);
            if(result.isEmpty()){
                result=adcontroller.Login(params1[0], params1[1]);
                if(result.isEmpty()){
                    result="User not found";
                }
            }
        }else{
                result="User already logged.";
            }



        }}
        return result;

    }

    @Override
    public String toStringCommand() {
        return "login email;psw";
    }
}
