package upm.comands.PublicCommand;

import upm.controllers.AdminController;
import upm.controllers.PlayerController;
import upm.controllers.TournamentController;
import upm.comands.Command;

public class TournamentListCommand extends Command {
    private PlayerController pcontroller;
    private AdminController tcontroller;
    private  TournamentController tourcontroller;

    public TournamentListCommand (TournamentController tourcontroller,PlayerController pcontroller,AdminController tcontroller){
        this.tourcontroller=tourcontroller;
        this.pcontroller=pcontroller;
        this.tcontroller=tcontroller;
    }

    @Override
    public String apply() {
        return null;
    }

    public String apply(String[] params){
        String result=super.testparams(params[0], "tournament-list",params.length,1);
         if (result != null && result.isEmpty())
                    if (pcontroller.getPlayerLoged()!=null){
                        result=tourcontroller.listTournamentsUser();
                    }else{
                        if(tcontroller.getAdminLogged()!=null){
                            result=tourcontroller.listTournamentsAdmin();
                        }else{
                            result=tourcontroller.listTournamentsNoAuth();
                        }
                    }

        return result;}
@Override
public String toStringCommand() {
        return "tournament-list";
        }
        }







