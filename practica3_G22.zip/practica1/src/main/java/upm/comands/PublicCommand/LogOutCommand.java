package upm.comands.PublicCommand;

import upm.controllers.AdminController;
import upm.controllers.PlayerController;
import upm.comands.Command;

public class LogOutCommand extends Command {

    private PlayerController pcontroller;
    private AdminController adminController;

    public LogOutCommand(PlayerController pcontroller,AdminController adminController) {
        this.pcontroller=pcontroller;
        this.adminController=adminController;

    }

    @Override
    public String apply() {
        return null;
    }

    @Override
    public String apply(String[] params) {
        String result=super.testparams(params[0],"logout",
                params.length,1);

        if (result!=null&&result.isEmpty()) {

            if(adminController.getAdminLogged()!=null){
                result=adminController.LogOut();
            }else{
                if(pcontroller.getPlayerLoged()!=null){
                result=pcontroller.LogOut();
                }else{
                    result="Can't log out beacause no user is logged.";
                }
            }

        }
        return result;

    }

    @Override
    public String toStringCommand() {
        return "logout";
    }
}
