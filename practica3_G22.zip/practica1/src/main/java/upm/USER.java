package upm;

public class USER {
    private UserType type;
    private final String email;
    private String password;
    boolean logged;

     public USER(String type , String email , String password){
         this.type=UserType.valueOf(type);
         this.email=email;
         this.password=password;
         this.logged=false;
     }



    public void setLogged(boolean logged) {
        this.logged = logged;
    }





    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

}
