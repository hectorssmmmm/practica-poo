package upm.controllers;

import upm.Admin;

import java.util.LinkedList;

public class AdminController {

   private UserController userController;
    private   LinkedList<Admin> admins;
    private  Admin adminLogged;
    public AdminController() {
        admins=new LinkedList<>();
        userController=new UserController();
        adminLogged=null;

    }

    public String Login(String email, String pswrd){
        String resul="";
        resul=userController.login(email,pswrd);
        if(resul.isEmpty()){
            int indexW = 0;
            Admin found1 = null;
            while (found1 == null && indexW < admins.size()) {
                Admin act = admins.get(indexW);
                if (act.getUser().getEmail().equals(email) && act.getUser().getPassword().equals(pswrd)) {
                    found1 = act;
                    found1.setLogged(true);
                    adminLogged = found1;
                    resul = "Admim logged correct!";
                }indexW++;
            }}else{
            resul="User wasn't found.";
        }
        return resul;

    }
    public  String LogOut(){
        String resul="";
        if(userController.logout().isEmpty()){
            adminLogged.getUser().setLogged(false);
           adminLogged=null;
            resul="Log out done.";
        }else {
            resul=userController.logout();
        }return resul;
    }



    public Admin getAdminLogged() {
        return adminLogged;
    }

}
