package upm.controllers;

import upm.USER;

import java.util.LinkedList;

public class UserController {
    private LinkedList<USER> list;
    private boolean logedUser;

    public UserController() {
        list = new LinkedList<USER>();
        logedUser =false;
    }

    public String login(String email, String psw) {
        String salida = "";
        if (!logedUser) {
            USER found = null;
            int indexW = 0;
            while (found == null && indexW < list.size()) {
                USER act = list.get(indexW);
                if (act.getEmail().equals(email) && act.getPassword().equals(psw)) {
                    found = act;
                    act.setLogged(true);
                    logedUser = true;
                }
                indexW++;
            }
        } else {
            salida = "Can't be logged beacause other user already logged.";
        }
        return salida;
    }
    public  String logout(){
        String resul="";
        if(logedUser){
            logedUser=false;
        }else{
            resul="No user is logged";
        }
        return  resul;
    }
    public LinkedList<USER> getList() {
        return list;
    }

    public void setList(LinkedList<USER> list) {
        this.list = list;
    }

    public boolean getLogedUser() {
        return logedUser;
    }

    public void setLogedUser(boolean logedUser) {
        this.logedUser = logedUser;
    }

}
