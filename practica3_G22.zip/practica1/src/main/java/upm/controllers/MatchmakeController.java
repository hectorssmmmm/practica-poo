package upm.controllers;

import upm.Matchmake;

import java.util.LinkedList;

public class MatchmakeController {
    private LinkedList<Matchmake> pairs;

    public MatchmakeController(){
        pairs=new LinkedList<Matchmake>();
    }

    public LinkedList<Matchmake> getPairs() {
        return pairs;
    }

}
