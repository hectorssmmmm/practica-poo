
package upm.controllers;

import upm.MatchmakeTeam;

import java.util.LinkedList;

public class MatchmakeTeamController {
    private LinkedList<MatchmakeTeam> pairsTeams;
    public MatchmakeTeamController(){

        pairsTeams=new LinkedList<MatchmakeTeam>();
    }
    public LinkedList<MatchmakeTeam> getPairsTeams() {
        return pairsTeams;
    }

    public void setPairsTeams(LinkedList<MatchmakeTeam> pairsTeams) {
        this.pairsTeams = pairsTeams;
    }
}
