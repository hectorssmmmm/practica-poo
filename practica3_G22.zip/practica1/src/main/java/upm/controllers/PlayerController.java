package upm.controllers;

import upm.Admin;
import upm.CLI;
import upm.Player;

import java.util.LinkedList;

public class PlayerController {
   private LinkedList<Player> playerlist;
    private Player playerLoged;
    private UserController userController;



    public PlayerController() {
        userController=new UserController();
        playerLoged=null;
        playerlist =new LinkedList<>();
    }
    public  String Login(String email, String pswrd){
        String resul;
        resul=userController.login(email,pswrd);
        if(resul.isEmpty()){
            int indexW = 0;
            Player found1 = null;
            while (found1 == null && indexW < playerlist.size()) {
                Player act = playerlist.get(indexW);
                if (act.getUser().getEmail().equals(email) && act.getUser().getPassword().equals(pswrd)) {
                    act.setLogged(true);
                    playerLoged = act;
                    resul = "Player logged correct!";
                }
                indexW++;
            }    }
        return resul;

    }

    public String LogOut(){
        String resul="";
        if(userController.logout().isEmpty()){
            playerLoged.getUser().setLogged(false);
            playerLoged=null;
            resul="Log out done.";
        }else {
            resul=userController.logout();
        }return resul;
    }



    public String createPlayer(String name, String surname, String id, String email, String password, Admin adminLoged) {
        String resul="";
        Player player = getPlayerViaID(id);
        if(player == null && !existPlayerWithEmail(email)){
            String regex = "^[\\w-\\.]+@[\\w-]+\\.[a-z]{2,6}$";
            if(email.matches(regex)) {
                player = new Player(name, surname, id, email, password, adminLoged);
                playerlist.add(player);
                resul = "Player: " + player.getName() + " " + player.getSurname() + ", successfully registered";
            }else{
                resul="The email does not fit the standard";
            }
        }else{
            resul="Error registering player";
        }
        return resul;
    }
    private boolean existPlayerWithEmail(String email) {
        int i = 0;
        boolean find = false;
        while(i < playerlist.size() && !find){
            if (playerlist.get(i).getUser().getEmail().equals(email)) {
                find = true;

            }i++;
        }
        return find;
    }

    public String deletePlayer(String id) {
        String resul="";
        Player player = getPlayerViaID(id);
        if(player != null){
            playerlist.remove(player);
            resul="Player: " + player.getName() + " " + player.getSurname() + ", successfully removed";
        }else{
            resul="Error removing player";
        }
        return resul;
    }



    public void listPlayers() {
        CLI cli=new CLI();
        if (!playerlist.isEmpty()) {
            for (int i = 0; i < playerlist.size() ; i++) {
               cli.print("Player: " + playerlist.get(i).getName() + " " + playerlist.get(i).getSurname());
            }
        }
    }

    private Player getPlayerViaID(String id) {
        Player p=null;
        for (int i = 0; i < playerlist.size(); i++) {
            if (playerlist.get(i).getId().equals(id)) {
                p= playerlist.get(i);
            }
        }
        return p;
    }
    public String showStatistics(String id, String option) {
        CLI cli= new CLI();
        String result="";
        Player player = getPlayerViaID(id);
        if (player == null) {
            result="Player not found with the id: " + id;
        } else {
            if (option.equals("-csv")) {
                cli.print("Statistics in CSV format: ");
                cli.print("Name;Surname;Points;Games Won;Assistance Points;Tournaments Won;Money Won");
                cli.print(player.getName() + ";" + player.getSurname() + ";" + player.getPoints() + ";" +
                        player.getGamesWon() + ";" + player.getAssistancePoints() + ";" + player.getTournamentsWon() + ";" + player.getMoneyWon());
            } else {
                if (option.equals("-json")) {
                    cli.print("Statistics in JSON format: ");
                    String JSON = "{" + "\"Name\": \"" + player.getName() + "\", " + "\"Surname\": \"" + player.getSurname() + "\", "
                            + "\"Points\": " + player.getPoints() + ", " + "\"Games Won\": " + player.getGamesWon() + ", "
                            + "\"Assistance Points\": " + player.getAssistancePoints() + ", " + "\"Tournaments Won\": " + player.getTournamentsWon() + ", "
                            + "\"Money Won\": " + player.getMoneyWon() + "}";
                    cli.print(JSON);
                } else {
                    result="The option you have chosen is invalid, use -csv or -json";
                }
            }
        }return result;
    }

    public  Player getPlayerLoged() {
        return playerLoged;
    }



    public  UserController getUserController() {
        return userController;
    }

    public void setPlayerLoged(Player playerLoged) {
        this.playerLoged = playerLoged;
    }

    public void setUserController(UserController userController) {
        this.userController = userController;
    }

    public LinkedList<Player> getPlayerlist() {
        return playerlist;
    }

    public void setPlayerlist(LinkedList<Player> playerlist) {
        this.playerlist = playerlist;
    }
}