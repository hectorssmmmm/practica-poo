package upm.controllers;

import upm.Admin;
import upm.Player;
import upm.Team;
import upm.controllers.PlayerController;

import java.util.LinkedList;

public class TeamController {
    private PlayerController pcontroller;
   private LinkedList<Team> teams;

    public TeamController(PlayerController pcontroller){
        this.pcontroller=pcontroller;
        teams = new LinkedList<>();

    }
    
    public String createTeam(String name, Admin adminLogged) {
        String resul="";

        Team team = getTeamViaName(name);
        if(team == null){
            team = new Team(name, adminLogged);
            teams.add(team);
            resul="Team: " + name + " , successfully registered";
        }else{
          resul="Error registering team";
        }return resul;
    }

    public String deleteTeam(String name) {
        String resul="";
        Team team = getTeamViaName(name);
        if(team != null){
            teams.remove(team);
            resul="Team: " + name + " , successfully removed";
        }else{
           resul ="Error removing team";
        }return resul;
    }

    public String  addPlayerToATeam( String StringId ,String name){
        String resul="";
        Player player=getPlayerViaID(StringId);
        Team team = getTeamViaName(name);

        if(team != null ){
            if(player!=null) {
                if(!team.playerInTeam(StringId)) {
                    team.getPlayers().getPlayerlist().add(player);
                    resul="Player: " + player.getName() + " " + player.getSurname() + ", successfully added to the team " + team.getName();
                }else{
                    resul="Player already in team";
                }
            }else{
                resul ="Player not found";
            }
        }else{
            resul="Team not found with that name: " + name;
        }
    return resul;}

    public String deletePlayerOfATeam(String playerId,String name){
        String resul="";
        Player player= getPlayerViaID(playerId);
        Team team = getTeamViaName(name);
        if(team != null){
            if(team.playerInTeam(playerId)){
                team.getPlayers().getPlayerlist().remove(player);
                resul="Player: " + player.getName() + " " + player.getSurname() + ", successfully removed of the team " + team.getName();
            }else{
                resul="Player isn't part of the team.";
            }
        }else{
            resul=("Team not found with that name : " +name);
        }return resul;
    }
    public String deletePlayer(String idPlayer){
    for(int i =0 ; i<teams.size();i++){
        for(int j=0 ; j<teams.get(i).getPlayers().getPlayerlist().size();j++){
            if (teams.get(i).getPlayers().getPlayerlist().get(j).getId().equals(idPlayer)) {
                teams.get(i).getPlayers().getPlayerlist().remove(j);
                return "Player removed from team:"+ teams.get(i).getName();
            }
        }
    }
    return "";
    }


    public Team getTeamViaName(String name) {
        for (int i = 0; i < teams.size(); i++) {
            if (teams.get(i).getName().equals(name)) {
                return teams.get(i);
            }
        }
        return null;
    }
    public Player getPlayerViaID(String id) {
        for (int i = 0; i < pcontroller.getPlayerlist().size(); i++) {
            if (pcontroller.getPlayerlist().get(i).getId().equals(id)) {
                return pcontroller.getPlayerlist().get(i);
            }
        }
        return null;
    }


    public LinkedList<Team> getTeams() {
        return teams;
    }

    public void setTeams(LinkedList<Team> teams) {
        this.teams = teams;
    }
}