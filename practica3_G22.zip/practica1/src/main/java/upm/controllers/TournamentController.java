package upm.controllers;

import upm.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.LinkedList;
import java.util.Random;

public class TournamentController {

    private TeamController teamController;

    private PlayerController playerController;
    private LinkedList<Tournament> tournaments;
    private Admin loggedAdmin;


    public TournamentController(PlayerController playerController, TeamController teamControllerpublic) {
        this.playerController = playerController;
        this.teamController = teamControllerpublic;
        this.loggedAdmin = null;
        tournaments = new LinkedList<>();
    }


    public LinkedList<Tournament> getTournaments() {
        return tournaments;
    }

    public String tournamentCreate(String name, String dateStart, String dateEnd, String league, String sport, String category, PlayerController pc, TeamController tc) {
        String resul = "";
        if(validDate(dateStart) && validDate(dateEnd)) {
            DateTimeFormatter dater= DateTimeFormatter.ofPattern("yyyyMMdd");
            LocalDate date1 = LocalDate.parse(dateStart,dater);
            LocalDate date2 = LocalDate.parse(dateEnd,dater);
            if (date1.isBefore(date2)) {
                Tournament tournament = new Tournament(name, dateStart, dateEnd, league, sport, loggedAdmin, category, pc, tc);
                tournaments.add(tournament);
                resul = "Tournament created ";
            }else{
                resul="Error ,start date after end date ";
            }

        }else{
            resul="Non valid dates , use yyyyMMdd format";
        }
        return resul;
    }
    private  boolean validDate(String date) {
        DateTimeFormatter dater = DateTimeFormatter.ofPattern("yyyyMMdd");
        try {
            LocalDate.parse(date, dater);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        } catch (Exception e) {
            return false;
        }
    }


    public Tournament findTournament(String name) {
        Tournament resul = null;
        for (int i = 0; i < tournaments.size(); i++) {
            if (tournaments.get(i).getName().equals(name)) {
                resul = tournaments.get(i);
            }
        }

        return resul;
    }

    public Team findTeam(String name, Tournament tournament) {
        Team resul = null;
        LinkedList<Team> list = tournament.getTeams().getTeams();

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getName().equals(name)) {
                resul = list.get(i);
            }
        }

        return resul;
    }

    public Player findPlayer(String id, Tournament tournament) {
        Player resul = null;
        LinkedList<Player> list = tournament.getPlayers().getPlayerlist();

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equals(id)) {
                resul = list.get(i);
            }
        }
        return resul;
    }

    public String tournamentEliminate(String name) {
        Tournament tournament = findTournament(name);
        if (tournament != null && tournaments.remove(tournament)) {
            return "Tournament eliminated";
        }
        return "Error eliminating tournament";
    }

    public String tournamentMatchmakingManualTeams(String name, String t1, String t2) {
        Tournament tournament = findTournament(name);
if(tournament!=null) {
    Team team1 = findTeam(t1, tournament);
    Team team2 = findTeam(t2, tournament);
    if (team1 != null && team2 != null) {
        if (!team1.isPairedTeam() && !team2.isPairedTeam()) {
            if (!team1.equals(team2)) {
                MatchmakeTeam pair = new MatchmakeTeam(team1, team2);
                tournament.getPairsTeams().getPairsTeams().add(pair);
                team1.setPairedTeam(true);
                team2.setPairedTeam(true);
            } else {
                return "They are the same team";
            }
        } else {
            return "One of the teams is already paired";
        }
    } else {
        return "One of the teams does not exist or is not in the tournament";
    }

    return "Matchmake done";
}else{
    return "Could not found tournament";
}
    }

    public String tournamentMatchmakingAutoTeams(String nameTournament) {
        Tournament tournament = findTournament(nameTournament);
        if(tournament!=null){
        int numTeams = tournament.getTeams().getTeams().size();
        Random rand = new Random();
        if (numTeams == 0) {
            return "There are no teams";
        } else {
            if (numTeams % 2 != 0) {
                return "Can't be paired because there are not peers teams unpaired. ";
            }

            LinkedList<Integer> availableIndices = new LinkedList<>();
            for (int i = 0; i < numTeams; i++) {
                if (!tournament.getTeams().getTeams().get(i).isPairedTeam()) {
                    availableIndices.add(i);
                }
            }


            while (availableIndices.size() > 1) {

                int r1 = rand.nextInt(availableIndices.size());
                Team team1 = tournament.getTeams().getTeams().get(availableIndices.get(r1));
                availableIndices.remove(r1);

                int r2 = rand.nextInt(availableIndices.size());
                Team team2 = tournament.getTeams().getTeams().get(availableIndices.get(r2));
                availableIndices.remove(r2);

                tournamentMatchmakingManualTeams(nameTournament, team1.getName(), team2.getName());

            }
            return "Random matchmake done.";

        }}else{
            return "Tournament not found";
        }
    }

    public String tournamentMatchmakingManualPlayers(String name, String p1, String p2) {
        Tournament tournament = findTournament(name);
        Player player1 = findPlayer(p1, tournament);
        Player player2 = findPlayer(p2, tournament);

        if (player1 != null && player2 != null) {
            if (!player2.isPaired() && !player2.isPaired()) {
                if (!player1.equals(player2)) {
                    Matchmake pair = new Matchmake(player1, player2);
                    tournament.getPairs().getPairs().add(pair);
                    player1.setPaired(true);
                    player2.setPaired(true);
                    return "Matchmake done";
                } else {
                    return "They are the same player";
                }
            } else {
                return "One of the players is already paired";
            }
        } else {
            return "One of the players does not exist or is not in the tournament";
        }
    }
    public String tournamentMatchmakingAutoPlayers(String nameTournament) {
        Tournament tournament = findTournament(nameTournament);
        if (tournament != null) {
            int numPlayers = tournament.getPlayers().getPlayerlist().size();
            Random rand = new Random();
            if (numPlayers == 0) {
                return "There are no players";
            } else {
                if (numPlayers % 2 != 0) {
                    return "Can't be paired because there are not peers players unpaired. ";
                }

                LinkedList<Integer> availableIndexes = new LinkedList<>();
                for (int i = 0; i < numPlayers; i++) {
                    if (!tournament.getPlayers().getPlayerlist().get(i).isPaired()) {
                        availableIndexes.add(i);
                    }
                }

                while (availableIndexes.size() > 1) {

                    int r1 = rand.nextInt(availableIndexes.size());
                    Player player1 = tournament.getPlayers().getPlayerlist().get(availableIndexes.get(r1));
                    availableIndexes.remove(r1);


                    int r2 = rand.nextInt(availableIndexes.size());
                    Player player2 = tournament.getPlayers().getPlayerlist().get(availableIndexes.get(r2));
                    availableIndexes.remove(r2);


                    tournamentMatchmakingManualPlayers(nameTournament, player1.getId(), player2.getId());

                }

                return "Random matchmake done.";
            }
        } else {
            return "Could not find tournament";
        }
    }

    public String inscribePlayer(String nameTournament) {
        Tournament tournament = findTournament(nameTournament);
        Player player = playerController.getPlayerLoged();
        if (tournament!=null && !tournament.isActive()) {
            tournament.getPlayers().getPlayerlist().add(player);
            return "Player has entered the tournament";
        }

        return "Tournament is currently active";
    }

    public String inscribeTeam(String nameTournament, String nameTeam) {
        Tournament tournament = findTournament(nameTournament);
        Player player = playerController.getPlayerLoged();
        Team team = teamController.getTeamViaName(nameTeam);
        if (team != null && tournament!=null && !tournament.isActive() ) {
            Team teamintour = findTeam(nameTeam, tournament);
            if (teamintour == null) {
                if (team.playerInTeam(player.getId())) {
                    if (team.getPlayers().getPlayerlist().size() > 1) {
                        tournament.getTeams().getTeams().add(team);
                        return "Team has entered the tournament";
                    } else {
                        return "Not enough players in team " + team.getName();
                    }
                } else {
                    return "Player not found in team" + nameTeam;
                }
            } else {
                return "Team already in tournament";
            }
        }
        return "Tournament is currently active or team is already in tournament";
    }

    public String eliminatePlayer(String nameTournament) {
        String resul="";
        Tournament tournament = findTournament(nameTournament);
        boolean found=false;
        if (tournament != null) {
            Player player = playerController.getPlayerLoged();
            resul+=DeletePlayersFromTournament(player.getId())+"\n";
            for (int i = 0; i < tournament.getPairs().getPairs().size(); i++) {
                if (tournament.getPairs().getPairs().get(i).getP1().getId().equals(playerController.getPlayerLoged().getId()) ||
                        tournament.getPairs().getPairs().get(i).getP2().getId().equals(playerController.getPlayerLoged().getId())) {
                    tournament.getPairs().getPairs().get(i).getP1().setPaired(false);
                    tournament.getPairs().getPairs().get(i).getP2().setPaired(false);
                    found=true;
                    tournament.getPairs().getPairs().remove(i);
                }
            }
            if(!found) {
               resul= "Player not found in tournament";
            }
        }else{
            resul= "Tournament not found";
        }
     return resul;

    }


    public String deleteTeamViaPlayer(String tournamentName, String teamName) {
        String result = "";
        Tournament tournament = findTournament(tournamentName);
        Player player = playerController.getPlayerLoged();
        Team team = teamController.getTeamViaName(teamName);
        if (tournament != null && team != null) {
            if (team.playerInTeam(player.getId())) {
                for (int j = 0; j < tournament.getTeams().getTeams().size(); j++) {
                    if (tournament.getTeams().getTeams().get(j).getName().equals(team.getName())) {
                        tournament.getTeams().getTeams().remove(j);
                        result = "Team has been eliminated from torunament \n";
                    }
                }
                for (int j = 0; j < tournament.getPairsTeams().getPairsTeams().size(); j++) {
                    if (tournament.getPairsTeams().getPairsTeams().get(j).getT1().getName().equals(team.getName()) || tournament.getPairsTeams().getPairsTeams().get(j).getT2().getName().equals(team.getName())) {

                        tournament.getPairsTeams().getPairsTeams().get(j).getT1().setPairedTeam(false);
                        tournament.getPairsTeams().getPairsTeams().get(j).getT2().setPairedTeam(false);
                        tournament.getPairsTeams().getPairsTeams().remove(j);
                        result += "Team has been eliminated from matchmake";
                    }
                }

            } else {
                return "Player not found in team " + teamName;
            }
        } else {
            result = "Tournament or team was not found";
        }
        return result;
    }

    public String DeleteTeam1(String nameTeam) {
        for (int i = 0; i < tournaments.size(); i++) {
            for (int j = 0; j < tournaments.get(i).getTeams().getTeams().size(); j++) {
                if (tournaments.get(i).getTeams().getTeams().get(j).getName().equals(nameTeam)) {
                    tournaments.get(i).getTeams().getTeams().remove(j);
                    return "Team has been eliminated from torunament";
                }

            }
        }
        return "";
    }

    public String DeleteTeam2(String nameTeam) {
        for (int i = 0; i < tournaments.size(); i++) {
            for (int j = 0; j < tournaments.get(i).getPairsTeams().getPairsTeams().size(); j++) {
                if (tournaments.get(i).getPairsTeams().getPairsTeams().get(j).getT1().getName().equals(nameTeam) || tournaments.get(i).getPairsTeams().getPairsTeams().get(j).getT2().getName().equals(nameTeam)) {
                    tournaments.get(i).getPairsTeams().getPairsTeams().get(j).getT1().setPairedTeam(false);
                    tournaments.get(i).getPairsTeams().getPairsTeams().get(j).getT2().setPairedTeam(false);
                    tournaments.get(i).getPairsTeams().getPairsTeams().remove(j);
                    return "Team has been eliminated from matchmake";
                }

            }
        }
        return "";
    }

    public String DeletePlayersFromTournament(String idPLayer) {
        for (int i = 0; i < tournaments.size(); i++) {
            for (int j = 0; j < tournaments.get(i).getPlayers().getPlayerlist().size(); j++) {
                if (tournaments.get(i).getPlayers().getPlayerlist().get(j).getId().equals(idPLayer)) {
                    tournaments.get(i).getPlayers().getPlayerlist().remove(j);
                    return "Player has been eliminated from torunament" + tournaments.get(i).getName();
                }

            }
        }
        return "";
    }

    public String DeletePlayerFromMatchmakes(String idPlayer) {
        for (int i = 0; i < tournaments.size(); i++) {
            for (int j = 0; j < tournaments.get(i).getPairs().getPairs().size(); j++) {
                if (tournaments.get(i).getPairs().getPairs().get(j).getP1().getId().equals(idPlayer) || tournaments.get(i).getPairs().getPairs().get(j).getP2().getId().equals(idPlayer)) {
                    tournaments.get(i).getPairs().getPairs().remove(j);
                    return "Player has been eliminated from torunament matchmake";
                }

            }
        }
        return "";
    }

    public String listTournamentsNoAuth() {
        String resul = "";
        CLI cli = new CLI();
        System.out.println("__________,xkxxmeicmie");
        for (int i = 0; i < tournaments.size(); i++) {

            cli.print(tournaments.get(i).getName());
            tournaments.get(i).getPlayers().listPlayers();
        }
        resul = "List succsesfully done.";
        return resul;
    }

    public PlayerController sortPlayersByPoints(PlayerController playerController) {
        PlayerController sortedController = new PlayerController();
        LinkedList<Player> tempPlayers = new LinkedList<>(playerController.getPlayerlist());

        while (!tempPlayers.isEmpty()) {
            Player topPlayer = null;
            int topIndex = -1;

            for (int i = 0; i < tempPlayers.size(); i++) {
                if (topPlayer == null || tempPlayers.get(i).getPoints() > topPlayer.getPoints()) {
                    topPlayer = tempPlayers.get(i);
                    topIndex = i;
                }
            }

            sortedController.getPlayerlist().add(topPlayer);

            tempPlayers.remove(topIndex);
        }

        return sortedController;
    }

    public String listTournamentsUser() {
        String resul = "";
        CLI cli = new CLI();
        PlayerController playersSorted = new PlayerController();

        for (int i = 0; i < tournaments.size(); i++) {
            playersSorted = sortPlayersByPoints(tournaments.get(i).getPlayers());
            cli.print(tournaments.get(i).getName());
            playersSorted.listPlayers();
        }
        resul = "List succsesfully done.";
        return resul;
    }

    public String listTournamentsAdmin() {
        String resul = "";
        CLI cli = new CLI();

        PlayerController playersSorted = new PlayerController();

        for (int i = 0; i < tournaments.size(); i++) {
            if (tournaments.get(i).isEnded()) {
                tournaments.remove(i);
            }
        }

        for (int i = 0; i < tournaments.size(); i++) {
            playersSorted = sortPlayersByPoints(tournaments.get(i).getPlayers());
            cli.print(tournaments.get(i).getName());
            playersSorted.listPlayers();
        }
        resul = "List succsesfully done.";
        return resul;
    }


    public String canDeletTeam(String param) {
        boolean resul=true;
        for (int i = 0; i < tournaments.size(); i++) {
            if (tournaments.get(i).isActive()) {
                if(findTeam(param,tournaments.get(i))!=null){
                    resul=false;
                }
            }
        }
        if(resul){
            return "";
        }else{
            return null;
        }

    }
}