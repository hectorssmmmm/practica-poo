package upm;

import upm.comands.*;
import upm.comands.AdminCommand.*;
import upm.comands.PlayerCommnads.StaticticsShowCommand;
import upm.comands.PlayerCommnads.TournamentAddCommand;
import upm.comands.PlayerCommnads.TournamentRemoveCommand;
import upm.comands.PublicCommand.LogOutCommand;
import upm.comands.PublicCommand.LoginCommand;
import upm.comands.PublicCommand.TournamentListCommand;
import upm.controllers.AdminController;
import upm.controllers.PlayerController;
import upm.controllers.TeamController;
import upm.controllers.TournamentController;


import java.util.LinkedList;

import java.util.List;

public class App {

    private PlayerController pcontroller;
    private AdminController adminController;
    private TeamController tcontroller;
    private TournamentController tourcontroller;

    private List<Command> commandList;
    private CLI cli;

    public App() {
        cli = new CLI();
        adminController=new AdminController();
        pcontroller=new PlayerController();
        tcontroller=new TeamController(pcontroller);
        tourcontroller=new TournamentController(pcontroller,tcontroller);
        commandList=new LinkedList<>();
        commandList.add(new LoginCommand(pcontroller,adminController));
        commandList.add(new LogOutCommand(pcontroller,adminController));
        commandList.add(new PlayerCreateComand(pcontroller,adminController));
        commandList.add(new PlayerDeleteCommand(pcontroller,adminController,tourcontroller,tcontroller));
        commandList.add(new TeamAddCommand(tcontroller,pcontroller,adminController));
        commandList.add(new TeamCreateCommand(tcontroller,adminController));
        commandList.add(new TeamDeleteCommand(tcontroller,adminController,tourcontroller));
        commandList.add(new TournamentCreateCommand(tourcontroller,adminController,pcontroller));
        commandList.add(new TournamentDeleteCommand(tourcontroller,adminController));
        commandList.add(new TeamRemoveCommand(tcontroller,adminController));
        commandList.add(new TournamentListCommand(tourcontroller,pcontroller,adminController));
        commandList.add(new TournamentMatchmakingCommand(tourcontroller,adminController));
        commandList.add(new TournamentRemoveCommand(tourcontroller,pcontroller));
        commandList.add(new TournamentAddCommand(tourcontroller,pcontroller));
        commandList.add(new StaticticsShowCommand(pcontroller));
    }

    public static void main(String[] args) {
        App a =new App();
        a.start();
    }

    private void start() {
        boolean salida=false;
        LinkedList<String> listacomandos=new LinkedList<String>();
        for (Command compro:commandList)
            listacomandos.add(compro.toStringCommand());

        while (!salida)
        {
            String command=cli.getCommand(listacomandos);

            if (command.equals("exit"))
                salida=true;
            else
            {
                String[] Stringsep = command.split(" ");

                StringBuffer Salida=new StringBuffer();

                for (Command compro:commandList)
                {
                    String SalidaParcial = compro.apply(Stringsep);
                    if (SalidaParcial!=null)
                        Salida.append(SalidaParcial).append("\n");

                }

                if (!Salida.toString().isEmpty())
                    cli.print(Salida.toString());
                else
                    cli.print("Command not found");
            }

        }


    }
}
