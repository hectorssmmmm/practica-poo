package upm;

public class Player {
 private Admin admin;
 private boolean paired;
 private boolean logged;

 private double points;
 private String name;
 private String surname;
 private String Id;
 private USER user;
 private int gamesWon;
 private double pointsMade;
 private double assistancePoints;
 private int tournamentsWon;
 private double moneyWon;

 public Player(String name, String surname, String Id,String email, String password, Admin admin) {
  this.admin = admin;
  this.points = 0.0;
  this.name = name;
  this.surname = surname;
  paired = false;
  logged = false;
  this.Id = Id;
  user = new USER("PLAYER", email, password);
  gamesWon = 0;
  pointsMade = 0;
  assistancePoints = 0;
  tournamentsWon = 0;
  moneyWon = 0;
 }


 public void setLogged(boolean logged) {
  this.logged = logged;
 }

 public Admin getAdmin() {
  return admin;
 }

 public void setAdmin(Admin admin) {
  this.admin = admin;
 }

 public boolean isPaired() {
  return paired;
 }

 public void setPaired(boolean paired) {
  this.paired = paired;
 }

 public double getPoints() {
  return points;
 }


 public String getName() {
  return name;
 }

 public void setName(String name) {
  this.name = name;
 }

 public String getSurname() {
  return surname;
 }



 public String getId() {
  return Id;
 }




 public USER getUser() {
  return user;
 }



 public int getGamesWon() {
  return gamesWon;
 }



 public double getPointsMade() {
  return pointsMade;
 }



 public double getAssistancePoints() {
  return assistancePoints;
 }



 public int getTournamentsWon() {
  return tournamentsWon;
 }



 public double getMoneyWon() {
  return moneyWon;
 }


}