package upm;

import org.junit.jupiter.api.Test;

class AppTest {
    @Test
    void testApp(){
        new App();
    }
}
